/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_date_current_date_monthday = '';
		let normal_date_img_date_week_img = '';
		let normal_analog_clock_time_pointer_hour = '';
		let normal_analog_clock_time_pointer_minute = '';
		let normal_analog_clock_time_pointer_second = '';
		let normal_background_bg_img1 = '';
		let normal_battery_current_text_img = '';
		let normal_step_current_text_img = '';
		let normal_alarm_jumpable_img_click = '';
		let normal_countdown_jumpable_img_click = '';
		let normal_heart_jumpable_img_click = '';
		let normal_step_jumpable_img_click = '';
		let normal_spo2_jumpable_img_click = '';
		let normal_stopwatch_jumpable_img_click = '';
		let normal_weather_jumpable_img_click = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 222,
					day_startY: 140,
					day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 141,
					y: 138,
					week_en: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					week_tc: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					week_sc: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0020.png',
					hour_centerX: 196,
					hour_centerY: 225,
					hour_posX: 25,
					hour_posY: 241,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0021.png',
					minute_centerX: 196,
					minute_centerY: 225,
					minute_posX: 25,
					minute_posY: 251,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0022.png',
					second_centerX: 195,
					second_centerY: 225,
					second_posX: 8,
					second_posY: 177,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 187,
					y: 216,
					w: 15,
					h: 16,
					src: '0023.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 161,
					y: 313,
					font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0034.png',
					unit_tc: '0034.png',
					unit_en: '0034.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 152,
					y: 279,
					font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 2,
					y: 287,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 289,
					y: 282,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 145,
					y: 2,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 4,
					y: 62,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 288,
					y: 66,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 288,
					y: 175,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.PRESSURE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 3,
					y: 175,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}