/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_background_bg_img3 = '';
		let normal_background_bg_img4 = '';
		let normal_background_bg_img5 = '';
		let normal_date_current_date_monthday = '';
		let normal_battery_pointer_progress_img_pointer = '';
		let normal_step_pointer_progress_img_pointer = '';
		let normal_analog_clock_time_pointer_hour = '';
		let normal_analog_clock_time_pointer_minute = '';
		let normal_analog_clock_time_pointer_second = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 312,
					y: 204,
					w: 59,
					h: 42,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 26,
					y: 157,
					w: 135,
					h: 135,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 127,
					y: 292,
					w: 135,
					h: 135,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 131,
					y: 295,
					w: 129,
					h: 129,
					src: '0005.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 30,
					y: 162,
					w: 127,
					h: 127,
					src: '0006.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 323,
					day_startY: 209,
					day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
					day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
					day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0017.png',
					center_x: 195,
					center_y: 361,
					x: 10,
					y: 55,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0018.png',
					center_x: 93,
					center_y: 225,
					x: 10,
					y: 55,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0019.png',
					hour_centerX: 196,
					hour_centerY: 226,
					hour_posX: 34,
					hour_posY: 139,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0020.png',
					minute_centerX: 196,
					minute_centerY: 226,
					minute_posX: 23,
					minute_posY: 177,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0021.png',
					second_centerX: 195,
					second_centerY: 226,
					second_posX: 14,
					second_posY: 178,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}